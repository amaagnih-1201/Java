package com.solveda.ob.testscript;
import org.testng.annotations.Test;
import com.solveda.ob.reporting.AutomationUtility;

public class Homepage extends AutomationUtility
{
	@Test(priority = 1, description="Homepage>> Test Case No.1>> Verify OB logo and categories on Homepage")
	public void Header_Links() throws Throwable
	{
		test=extent.createTest("Verify OB logo and categories on Homepage");
		// Verifying OB logo
		validateMultipleIDs("HomePage_ID", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_1", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_2", "Home Page");
	}	

	@Test(priority = 2, description="Homepage>> Test Case No.2>> Verify Second layer header")
	public void Second_Layer_header()
	{
		test=extent.createTest("Verify Second header layer is displaying");
		validateMultipleIDs("HomePage_Secondlayer_ID", "Home Page");

	}

	@Test(priority = 3, description="Homepage>> Test Case No.2 >> Verify Homepage main Banner")
	public void Banner()
	{
		test=extent.createTest("Verify Homepage main Banner section");
		validateMultipleIDs("HomePage_Banner", "Home Page");
	}

	@Test(priority = 4, description="Homepage>> Test Case No.4 >> Verify insight for business success section is displaying")
	public void InSightBusiness()
	{
		test=extent.createTest("Verify insight for business success section is displaying");
		validateMultipleIDs("InsightBusiness", "Home Page");
	}

	@Test(priority = 5, description="Homepage>> Test Case No.5 >> Verify sitemap and contact us is displaying on homepage")
	public void SiteMap() throws Throwable
	{
		test=extent.createTest("Verify sitemap and contact us is displaying on homepage");
		validateMultipleIDs("HomePage_Footer_ID", "Home Page");
		validateMultipleLinksXPath("HomePage_Footer_Link", "Home Page");
	}

}

