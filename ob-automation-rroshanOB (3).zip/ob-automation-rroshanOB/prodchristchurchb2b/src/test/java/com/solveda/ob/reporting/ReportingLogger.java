package com.solveda.ob.reporting;

import com.aventstack.extentreports.ExtentTest;

public class ReportingLogger extends AutomationUtility {

	public static ExtentTest test;
	
	public ExtentTest getTestLogger() {
		
		test=extent.createTest("Info from Logger");
		
		return test;
		
		
	}
}
