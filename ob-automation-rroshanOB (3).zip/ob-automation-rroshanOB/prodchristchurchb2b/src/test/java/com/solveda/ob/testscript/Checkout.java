package com.solveda.ob.testscript;



import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.solveda.ob.reporting.*;

public class Checkout extends AutomationUtility implements XPathConstants
{

	@Test(priority = 1, description="Shopping Cart>> Verify user is able to clear cart from Remove order button")
	public void addtoCart() throws Throwable
	{
		test=extent.createTest("Verify user is able to clear cart from Remove order button");
		String error = null;
		try {
			System.out.println("Checkout addtoCart Login");
			login();

			navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

			add_PLPItemToCart(PLPItem, AddtoCartButton);

			show_miniCart(CartIconOnHeader, ItemNameInCartXpath);

			remove_ItemFromCart(RemoveOrderCartXpath);
			Thread.sleep(5000);
			driver.navigate().refresh();

			validate_CartCount(CartCountonHeaderXpath, "0");

		} catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("Checkout addtoCart Login");
			signout();
		}
	}


	@Test(priority = 2, description="Shopping Cart>> Verify item is removing from cart with remove link on item")
	public void clearCart() throws Throwable
	{
		test=extent.createTest("Verify item is removing from cart with remove link on item");
		String error = null;
		try 
		{
			System.out.println("Checkout clearCart Login");
			login();

			navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

			add_PLPItemToCart(PLPItem, AddtoCartButton);

			show_miniCart(CartIconOnHeader, ItemNameInCartXpath);

			remove_ItemFromCart(RemoveOrderCartXpath);
			Thread.sleep(5000);
			driver.navigate().refresh();

			validate_CartCount(CartCountonHeaderXpath, "0");

		} catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("Checkout clearCart Signout");
			signout();
		}
	}

	@Test(priority = 3, description="Shopping Cart>> Verify user is able to add item from Quick Order")
	public void quickOrder() throws Throwable
	{
		test=extent.createTest("Verify user is able to add item from Quick Order");
		String error = null;
		try {
			System.out.println("Checkout quickOrder Login");
			login();

			add_ItemToQuickOrder(CartIconXpath, QuickOrderOnCartXpath, ProductCodeTextBoxOnQuickOrderXpath,
					ProductCode, AddtoCartonQuickOrder, ProductCodeOnCart);

			remove_ItemFromCart(RemoveOrderCartXpath);
			Thread.sleep(5000);
			driver.navigate().refresh();

			validate_CartCount(CartCountonHeaderXpath, "0");

		} catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("Checkout quickOrder Signout");
			signout();
		}
	}

	@Test(priority = 4, description="Checkout>> Verify checkout as logged in user")
	public void checkOut_forLoggedInUser() throws Throwable
	{
		test=extent.createTest("Verify checkout as logged in user");
		String error = null;
		try {
			System.out.println("Checkout checkOut_forLoggedInUser Login");
			login();

			add_ItemToQuickOrder(CartIconXpath, QuickOrderOnCartXpath, ProductCodeTextBoxOnQuickOrderXpath,
					ProductCode, AddtoCartonQuickOrder, ProductCodeOnCart);

			navigate_ToCheckoutSection(CartIconXpath, CheckOutButton);

			if(MinimumAmount!= null && MinimumAmount.equalsIgnoreCase("true"))
			{
				//driver.switchTo().alert().accept();
			}

			add_ToShippingInstructions(OrderTotalOnCheckoutHeader, OrderTotalOnCheckoutOrderSummary, ShippingInstructions);

			checkout_selectPaymentMethod(PaymentMethod);

			if(enableCCOnPayment != null && enableCCOnPayment.equalsIgnoreCase("true"))
			{
				checkout_addCCDetails();
			}

			perform_checkout();

			navigate_toOrderConfirmation();

		} catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("Checkout checkOut_forLoggedInUser Signout");
			signout();
		}

	}

	//Not appliable for OPD	
	@Test(priority = 5, description="Order History>> Verify product is adding to cart from order history")
	public void addProductFromOrderHistory() throws Throwable
	{
		{
			test=extent.createTest("Verify product is adding to cart from order history");
			String error = null;
			try {
				System.out.println("Checkout addProductFromOrderHistory Login");
				login();

				if(ReOrderButton != null && ReOrderButton.equalsIgnoreCase("true"))
				{
					add_ItemFromHistory_ToCart(MyAccountIconIconXpath, OrderHistoryinMyAccountXpath, OrderLinkinOrderHistoryXpath, ReOrderButtononOrderHistory,ItemNameInCartXpath);

					remove_OrderedCart(RemoveOrderCartXpath);
				}

			} catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("Checkout addProductFromOrderHistory Signout");
				signout();
			}

		}

	}

	@Test(priority = 6, description="Order History>> Verify product is adding to fav list from cart")
	public void addtoFavFromCart() throws Throwable
	{
		{
			test=extent.createTest("Verify product is adding to fav list from cart");
			String error = null;
			try {
				System.out.println("Checkout addtoFavFromCart Login");
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

				login();

				add_ItemToFav_FromQuickOrder(CartIconXpath, QuickOrderOnCartXpath, ProductCodeTextBoxOnQuickOrderXpath, ProductCode, AddtoCartonQuickOrder, AddToFavouritLinkOnCart, RadioButtonOnFavList, FavListNameInputBox, AddToFavButton, ContinueShoppingButton);

				remove_FavItem_FromCart(RemoveOrderCartXpath);

				add_FavItem_ToCart(FavIconOnHeader, AddTocartIconIDonFavlist,ItemNameInCartXpath);

				remove_FavItem_FromCart(RemoveOrderCartXpath);

				add_FavList(FavListIconOnHeader, FavListLinkText, AddtoCurrentOrderButtonXpath);

				remove_FavItem_FromCart(RemoveOrderCartXpath);

				delete_FavListFromCart(FavIconOnHeader,DeleteFavListId, TextMessageOnFavlistdeletionXpath, ClosePopup);

			} catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("Checkout addtoFavFromCart Signout");
				signout();
			}

		}
	}
}
