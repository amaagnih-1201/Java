package com.solveda.ob.testscript;
import java.io.*;
import java.util.*;

public class PropReader {

	private static Properties prop=null;



	public static String getProp(String args)  
	{
		if(prop==null)
		{
			//prop = readPropertiesFile(constantFileName);
			prop = readPropertiesFile(System.getProperty("siteName") + ".properties");
			System.out.println("Property File :- "+System.getProperty("siteName") + ".properties");
		}

		//System.out.println("URL :- "+System.getProperty("url"));
		return prop.getProperty(args);
	}

	private static Properties readPropertiesFile(String fileName) 
	{
		FileInputStream fis = null;
		Properties prop = null;
		try {
			fis = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(fis);
		}
		catch(FileNotFoundException fnfe) 
		{
			fnfe.printStackTrace();
		}
		catch(IOException ioe) 
		{
			ioe.printStackTrace();
		}
		finally {
			try {
				fis.close();
			}
			catch(IOException e)
			{}  
		}
		return prop;
	}
}
