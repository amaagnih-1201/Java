package com.solveda.ob.testscript;


import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.solveda.ob.reporting.AutomationUtility;
import com.solveda.ob.reporting.*;

public class Login extends AutomationUtility implements XPathConstants {


	@Test(priority = 1, description="Login and Reg>> Verify user is able to login")
	public void SignIn() throws Throwable
	{
		test=extent.createTest("Verify user is able to login");
		String error = null;
		try {
			System.out.println("Login>SignIn Login");
			login();
			error="My account icon";
			// wait for my account icon on header
			wait(By.xpath(MyAccountIconIconXpath));
			// verify my account icon is displaying
			validateMultipleLinksXPath("MyAccount_XPathLink", "Login");

		} catch(AssertionError e)
		{
			test=extent.createTest("Verify user is able to login");
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("Login>SignIn Signout");
			signout();
			wait(By.xpath(LoginIconXpath));
			validateMultipleLinksXPath("Login_XPathLink", "Login");
		}

	}
}