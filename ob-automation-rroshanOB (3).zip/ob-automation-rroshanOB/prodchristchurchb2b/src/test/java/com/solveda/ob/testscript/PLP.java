package com.solveda.ob.testscript;


import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import com.solveda.ob.reporting.AutomationUtility;
import com.solveda.ob.reporting.XPathConstants;

public class PLP extends AutomationUtility implements XPathConstants
{

	@Test(priority = 1, description="PLP >> Verify category navigation redirecting to PLP")
	public void PLPRedirection() throws Throwable
	{
		{
			driver.navigate().refresh();
			test=extent.createTest("Verify category navigation redirecting to PLP");
			// Fetching locator address from property file

			navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

			// Verify white copy paper title is displaying on PLP
			validateMultipleLinksXPath("PLP_title_XPathLink", "PLP");    		    
		}

	}

	@Test(priority = 2, description="PLP >> Verify redirection to product")
	public void navigatePDPFromSearch() throws Throwable
	{
		{
			driver.navigate().refresh();
			test=extent.createTest("Verify redirection to product");
			try {

				// Wait for search input box
				execute_search(SearchInputBoxXpath, ProdcutNametosearch, SearchButtonClass, SearchResultPageTitleXpath);

				navigate_searchResult(FirstItemNameOnSearchResultPage, SearchResultPageItem, ItemNameOnPDPAfterSearchResultXpath);

			} catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(" is not displayed", ExtentColor.RED));
			}


		}
	}

	@Test(priority = 3, description="PLP >> Verify item is adding to cart from search page" )
	public void addItemsFromSearchPage() throws Throwable
	{
		{
			driver.navigate().refresh();
			test=extent.createTest("Verify item is adding to cart from search page");
			String error = null;
			try {
				System.out.println("PLP addItemsFromSearchPage Login");
				login();
				// Wait for search input box
				execute_search(SearchInputBoxXpath, ProdcutNametosearch, SearchButtonClass,SearchResultPageTitleXpath);

				// Verify search result page title is displaying
				validateMultipleLinksXPath("SearchResult_XPathLink", "PLP");
				Thread.sleep(2000);
				add_ItemFromSearchPage(AddtoCartButton, CartIconXpath, ItemNameInCartXpath);
				// Verifying item is being displayed
				error="Item on cart";
				validateMultipleLinksXPath("ItemNameInCart_XPathLink", "PLP");

				// Wait for remove item link displaying with item
				Thread.sleep(2000);

				remove_ItemCart(RemoveItemCartXpath);
				
				Thread.sleep(5000);
				driver.navigate().refresh();

				// Verify cart count decreased to 0
				validate_CartCountHeader(CartCountonHeaderXpath, "0");

			} catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("PLP addItemsFromSearchPage Signout");
				Thread.sleep(2000);
				signout();
			}

		}


	}	

	@Test(priority = 4, description="PLP >> Verify item is adding to cart from PLP")
	public void addtoCartFromPLP() throws Throwable
	{
		driver.navigate().refresh();
		test=extent.createTest("Verify item is adding to cart from PLP");
		String error = null;
		try {
			System.out.println("PLP addtoCartFromPLP Login");

			login();

			navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

			add_PLPItemToCart(PLPItem, AddtoCartButton);

			show_miniCart(CartIconOnHeader, ItemNameInCartXpath);

			remove_ItemFromCart(RemoveOrderCartXpath);
			
			Thread.sleep(5000);
			driver.navigate().refresh();

			validate_CartCount(CartCountonHeaderXpath, "0");

		} catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("PLP addtoCartFromPLP Signout");
			signout();
		}
	}

	@Test(priority = 5, description="PLP >> Verify product is adding to Favourites via PLP")
	public void AddtoFavouritePLP() throws Throwable
	{
		driver.navigate().refresh();
		test=extent.createTest("Verify product is adding to Favourites");
		String error = null;
		try {
			System.out.println("PLP AddtoFavouritePLP Login");

			login();

			navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

			add_FavToList_FromPLP(PLPItem, AddtoFavouritesPLPSearch, RadioButtonOnFavList, FavListNameInputBox, AddToFavButton, ContinueShoppingButton);

			navigate_ToFav_FromPLP(FavIconOnHeader, FavNameInFavListXpath);

			delete_FavList();

		} 	    
		catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("PLP AddtoFavouritePLP Signout");
			signout();
		}
	}


	@Test(priority = 6, description="PLP >> Verify product is adding to Favourites via Search")
	public void AddtoFavouriteSearch() throws Throwable
	{
		driver.navigate().refresh();
		test=extent.createTest("Verify product is adding to Favourites");
		String error = null;
		try {
			System.out.println("PLP AddtoFavouriteSearch Login");
			login();


			add_FavSearch(SearchInputBoxXpath, SearchButtonClass, SearchResultPageTitleXpath, PLPItem, AddtoFavouritesPLPSearch, CreateNewFavList, FavListNameSearch, AddtoFavButtonSearch);

			navigate_ToFav_FromPLP(FavIconOnHeader, FavNameInFavListXpath);

			delete_FavList();

		} 	    
		catch(AssertionError e)
		{
			test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
		}
		finally {
			System.out.println("PLP AddtoFavouriteSearch Signout");
			signout();
		}
	}




}






