package com.solveda.ob.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.solveda.ob.reporting.ReportingLogger;
import com.solveda.ob.testscript.PropReader;

public class Setup {

	public static WebDriver driver;
	public static ExtentTest test;

	String error = null;

	public void Start() {
		
		System.setProperty("webdriver.gecko.driver", "./solveda.Inputs/FF.exe");

		FirefoxOptions options = new FirefoxOptions();
		options.setHeadless(true);
		System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE, "true");
		System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");
		
		driver = new FirefoxDriver(options);
		
		System.out.println("driver is initiated " + driver);
		driver.get(PropReader.getProp("url"));

		
	}

	public void Mouseover(By by) throws InterruptedException {
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(by)).build().perform();
	}

	public void Stop() {
		driver.close();
	}

	public void wait(By by) throws Throwable {

		try {

			WebDriverWait wait = new WebDriverWait(driver, 50);
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			

		} catch (Exception e) {
			ReportingLogger reportinglogger = new ReportingLogger();
			test = reportinglogger.getTestLogger();
		
		}
	}

	public void clickablewait(By by) {
		WebDriverWait clickablewait = new WebDriverWait(driver, 30);
		clickablewait.until(ExpectedConditions.elementToBeClickable(by));
	}

}
