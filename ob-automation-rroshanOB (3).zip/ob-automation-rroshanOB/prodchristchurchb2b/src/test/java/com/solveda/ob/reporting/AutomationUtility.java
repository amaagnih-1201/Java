package com.solveda.ob.reporting;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.solveda.ob.testscript.PropReader;
import com.solveda.ob.utilities.Setup;

public class AutomationUtility extends Setup implements XPathConstants {

	public static ExtentHtmlReporter htmlreporter;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static File rootFolder = new File(System.getProperty("user.dir"));
	String error = null;

	@BeforeSuite
	public void report() throws Throwable {

		htmlreporter = new ExtentHtmlReporter(
				System.getProperty("user.dir") + "/solveda.test-output/OB_Test_Report.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlreporter);
		extent.setSystemInfo("Application", reader("application"));
		extent.setSystemInfo("Environment", reader("environment"));
		extent.setSystemInfo("QA", reader("qa"));
		extent.setSystemInfo("Browser", reader("browser"));
		htmlreporter.config().setDocumentTitle("Smoke Test Report");
		htmlreporter.config().setReportName("Smoke Test");
		htmlreporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlreporter.config().setTheme(Theme.DARK);

		Start();

	}

	@AfterMethod
	public void getResult(ITestResult result) throws IOException {
		test = extent.createTest("After Test " + result.getMethod().getDescription());

		if (result.getStatus() == ITestResult.FAILURE) {
			// test.log(Status.FAIL,
			// MarkupHelper.createLabel(result.getMethod().getDescription(),
			// ExtentColor.RED));
			test.fail(result.getThrowable());
			Date currentdate = new Date();
			String screenshotfilename = currentdate.toString().replace(" ", "-").replace(":", "-");
			System.out.println(screenshotfilename + " " + result.toString());
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File(".//screenshots//" + screenshotfilename + ".png"));

		} else if (result.getStatus() == ITestResult.SUCCESS) {

			test.log(Status.PASS, MarkupHelper.createLabel(result.getMethod().getDescription(), ExtentColor.GREEN));
		} else {
			test.log(Status.SKIP, MarkupHelper.createLabel(result.getMethod().getDescription(), ExtentColor.YELLOW));
			test.skip(result.getThrowable());
		}

	}

	@AfterSuite
	public void endReport() {
		extent.flush();
		Stop();
	}

	public String reader(String in) throws IOException {
		Properties obj = new Properties();
		FileInputStream objFile;
		objFile = new FileInputStream(System.getProperty("user.dir") + "./solveda.configuration.properties");
		obj.load(objFile);
		String out = obj.getProperty(in);
		return out;
	}

	// link xpath validation
	public void validateXpathIfEnabled(String path, String parentComponent) throws Throwable {
		try {
			String linkXPath = PropReader.getProp(path + "Xpath");
			error = path + " on " + parentComponent;
			wait(By.xpath(linkXPath));
			Assert.assertTrue(driver.findElement(By.xpath(linkXPath)).isEnabled());
		} catch (Exception e) {
			// test.log(Status.FAIL, MarkupHelper.createLabel(error + " is not enabled",
			// ExtentColor.RED));
		}
	}

	// ID
	public void validateIdIfExists(String comp, String parentComponent) {
		try {
			String compId = PropReader.getProp(comp + "Id");
			error = compId + " on " + parentComponent;
			Assert.assertTrue(driver.findElement(By.id(compId)).isDisplayed());
		} catch (Exception e) {
			// test.log(Status.FAIL, MarkupHelper.createLabel(error + " is not displayed",
			// ExtentColor.RED));
		}

	}

	// CSS
	public void validateCSSIfDisplayed(String comp, String parentComponent) {
		try {
			String compCSS = PropReader.getProp(comp + "CSS");
			error = compCSS + " on " + parentComponent;
			Assert.assertTrue(driver.findElement(By.cssSelector(compCSS)).isDisplayed());
		} catch (Exception e) {
			// test.log(Status.FAIL, MarkupHelper.createLabel(error + " is not displayed",
			// ExtentColor.RED));
		}

	}

	// Class
	public void validateClassIfDisplayed(String comp, String parentComponent) {
		try {
			String compClass = PropReader.getProp(comp + "Class");
			error = compClass + " on " + parentComponent;
			Assert.assertTrue(driver.findElement(By.className(compClass)).isDisplayed());
		} catch (Exception e) {
			// test.log(Status.FAIL, MarkupHelper.createLabel(error + " is not displayed",
			// ExtentColor.RED));
		}

	}

	public void validateMultipleLinksXPath(String linksProperty, String parentComponent) throws Throwable {
		String linksPath = PropReader.getProp(linksProperty);
		if (linksPath != null) {

			StringTokenizer st = new StringTokenizer(linksPath, ",");
			while (st.hasMoreTokens()) {
				String nextPath = st.nextToken();
				System.out.println(nextPath);
				validateXpathIfEnabled(nextPath, parentComponent);
			}
		}
	}

	public void validateMultipleIDs(String idsProperty, String parentComponent) {
		String idsPath = PropReader.getProp(idsProperty);
		if (idsPath != null) {
			StringTokenizer st = new StringTokenizer(idsPath, ",");
			while (st.hasMoreTokens()) {
				String nextPath = st.nextToken();
				validateIdIfExists(nextPath, parentComponent);
			}
		}
	}

	public void validateMultipleCSSElements(String cssProperty, String parentComponent) {
		String cssPath = PropReader.getProp(cssProperty);
		if (cssPath != null) {
			StringTokenizer st = new StringTokenizer(cssPath, ",");
			while (st.hasMoreTokens()) {
				String nextPath = st.nextToken();
				validateCSSIfDisplayed(nextPath, parentComponent);
			}
		}
	}

	public void validateMultipleClassElements(String classProperty, String parentComponent) {
		String classPath = PropReader.getProp(classProperty);
		if (classPath != null) {
			StringTokenizer st = new StringTokenizer(classPath, ",");
			while (st.hasMoreTokens()) {
				String nextPath = st.nextToken();
				validateCSSIfDisplayed(nextPath, parentComponent);
			}
		}
	}

	public void validate_CartCountHeader(String CartCountonHeaderXpath, String cartCountValueToMatch) {
		Assert.assertEquals(driver.findElement(By.xpath(CartCountonHeaderXpath)).getText(), cartCountValueToMatch);
	}

	public void validateCartToEmpty() throws Throwable {

		driver.navigate().refresh();
		Thread.sleep(5000);

		System.out.println("Validation Started for Cart");
		for (int i = 0; i < 4; i++) {
			try {
				System.out.println("Checking items in a cart.");
				if(driver.findElement(By.xpath(CartCountonHeaderXpath)).getText().equals("0")) {	
					System.out.println("Cart is already empty");
				}
				else {
					Thread.sleep(5000);
					show_miniCart(CartIconOnHeader, ItemNameInCartXpath);
					System.out.println("Removing Items from the cart.");
					Thread.sleep(5000);
					remove_ItemFromCart(RemoveOrderCartXpath);
					System.out.println("Items removed");
					System.out.println("Cart is empty now");
				}
				break;
			}
			catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			} 
		}

	}
	public void validateFavList()  {
		driver.navigate().refresh();
		try {
			Thread.sleep(5000);
			System.out.println("Validation Started for Favourite list");
			wait(By.xpath(FavIconOnHeader));
			driver.findElement(By.xpath(FavIconOnHeader)).click();
		} catch (Throwable e) {
			return;
		}
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(2000);

				if(driver.findElement(By.xpath("//*[contains(text(), 'Automation')]")).isDisplayed())
				{
					System.out.println("Deleting Favourite list that has already been created");
					try {
						Thread.sleep(2000);
						wait(By.xpath(FavlistDelete));
						driver.findElement(By.xpath(FavlistDelete)).click();
						Thread.sleep(2000);
						driver.switchTo().alert().accept();
						Thread.sleep(2000);
						System.out.println("Favourite list Deleted");
						Thread.sleep(3000);
					} catch (Throwable e) {
						return;
					}
				}

				break;

			} catch (Exception e) {
				try {
					if(driver.findElement(By.xpath("//*[contains(text(), 'You have not created any favourite lists yet.')]")).isDisplayed())
					{
						System.out.println("No Favourite list is created");
					}
				} catch (Exception e1) {
					return;
				}
				if (i > 2) {
				} 
			}
		}
	}
	
	public void navigate_ToPDPPage_fromPLP(String fromPLPItem) throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				driver.navigate().refresh();
				Thread.sleep(2000);
				// Waiting for item item loading on PLP

				wait(By.xpath(fromPLPItem));
				// Adding scroll to scroll page for item visibility
				JavascriptExecutor js = (JavascriptExecutor) driver;
				int val = i * 100;
				val = 650 - val;
				js.executeScript("window.scrollBy(100," + val + ")");

				driver.findElement(By.xpath(gotoPDP)).click();

				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}
	}

	public void navigate_ToCategoryPage(String L1CategoryXPath, String L2CategoryLinkPath, String L3CategoryTextXPath)
			throws Throwable {

		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(5000);
				// Added wait for navigation category in header
				wait(By.xpath(L1CategoryXPath));
				// Mousehover on paper supply category on header
				Mouseover(By.xpath(L1CategoryXPath));
				// Added wait for visibility of sub-category
				wait(By.linkText(L2CategoryLinkPath));
				// Clicking on copy paper sub-category
				driver.findElement(By.linkText(L2CategoryLinkPath)).click();
				// Added wait for visibility of white copy paper category on copy paper PLP
				wait(By.xpath(L3CategoryTextXPath));
				// Clicking on white copy paper category on paper PLP
				Thread.sleep(5000);
				driver.findElement(By.xpath(L3CategoryTextXPath)).click();
				Thread.sleep(5000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				} else
					e.printStackTrace();
			}
		}

	}

	public void navigate_searchResult(String FirstItemNameOnSearchResultPage, String SearchResultPageItem,
			String ItemNameOnPDPAfterSearchResultXpath) throws Throwable {
		wait(By.xpath(FirstItemNameOnSearchResultPage));
		String ItemNameOnSearchResultPage = driver.findElement(By.xpath(FirstItemNameOnSearchResultPage)).getText();
		System.out.println(ItemNameOnSearchResultPage);
		driver.findElement(By.xpath(gotoPDP)).click();

		wait(By.xpath(ItemNameOnPDPAfterSearchResultXpath));
		String ItemNameOnPDP = driver.findElement(By.xpath(ItemNameOnPDPAfterSearchResultXpath)).getText();
		System.out.println(ItemNameOnPDP);
		Thread.sleep(2000);
		Assert.assertEquals(ItemNameOnPDP, ItemNameOnSearchResultPage);

	}

	public void navigate_ToCheckoutSection(String CartIconXpath, String CheckOutButton) throws Throwable {
		wait(By.xpath(CartIconXpath));
		driver.findElement(By.xpath(CartIconXpath)).click();

		wait(By.xpath(CheckOutButton));
		driver.findElement(By.xpath(CheckOutButton)).click();

		Thread.sleep(3000);
	}

	public void navigate_ToFav_FromPLP(String FavIconOnHeader, String FavNameInFavListXpath) throws Throwable {
		driver.navigate().refresh();
		Thread.sleep(10000);
		wait(By.xpath(FavIconOnHeader));
		driver.findElement(By.xpath(FavIconOnHeader)).click();
		wait(By.xpath(FavNameInFavListXpath));
		validateMultipleLinksXPath("FavlistName_XpathLink", "PLP");
		error = "Favourite List";
		Thread.sleep(2000);

	}

	public void navigate_ToFavList(String FavIconOnHeader, String FavNameInFav, String FavlistDelete,
			String FavlistDeleteClose) throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(10000);
				wait(By.xpath(FavIconOnHeader));
				driver.findElement(By.xpath(FavIconOnHeader)).click();
				wait(By.xpath(FavNameInFav));
				error = "Favourite List";
				Assert.assertTrue(driver.findElement(By.xpath(FavNameInFav)).isDisplayed());
				Thread.sleep(2000);
				break;

			} catch (Exception e) {
				if (i > 2) {
					throw e;
				} else
					e.printStackTrace();
			}
		}
		wait(By.xpath(FavlistDelete));
		driver.findElement(By.xpath(FavlistDelete)).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		// driver.findElement(By.xpath(FavlistDeleteClose)).click();
		Thread.sleep(2000);

	}

	public void validate_CartCount(String cartCounterPath, String cartCountValueToMatch) {
		Assert.assertEquals(driver.findElement(By.xpath(cartCounterPath)).getText(), cartCountValueToMatch);
	}

	public void navigate_toOrderConfirmation() throws Throwable {
		wait(By.xpath(OrderConfirmationHeader));
		Assert.assertTrue(driver.findElement(By.xpath(OrderConfirmationHeader)).isDisplayed());
		wait(By.xpath(OrderConfirmationMessage));
		Assert.assertTrue(driver.findElement(By.xpath(OrderConfirmationMessage)).isDisplayed());
	}

	public void show_miniCart(String cartIcon, String ItemName) throws Throwable {
		driver.navigate().refresh();
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		;

		wait(By.xpath(cartIcon));
		WebElement element2 = driver.findElement(By.xpath(cartIcon));
		js.executeScript("arguments[0].click();", element2);
		// Clicking on cart icon on header
		// driver.findElement(By.xpath(cartIcon)).click();
		wait(By.xpath(ItemName));
		// Verifying item is being displayed
		error = "Item on cart";
		// Assert.assertTrue(driver.findElement(By.xpath(ItemName)).isDisplayed());
		Thread.sleep(2000);

	}

	public void add_PLPItemToCart(String plpItem, String addToCartButtonPath) throws Throwable {

		wait(By.xpath(plpItem));
		// Adding scroll to scroll page for item visibility
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,550)");
		// Mousehover on item to view add to cart button
		Mouseover(By.xpath(plpItem));

		// Waiting for add to cart button visibility after mousehover
		wait(By.xpath(addToCartButtonPath));
		// Clicking on add to cart button for the item
		driver.findElement(By.xpath(addToCartButtonPath)).click();
		// Added sleep wait to add item in cart and item load in cart
		Thread.sleep(2000);

	}

	public void add_PDPItemToCart(String plpItem, String AddToCartButtononPDPpath) throws Throwable {
		driver.navigate().refresh();
		for (int i = 0; i < 4; i++) {
			try {
				wait(By.xpath(plpItem));
				// Adding scroll to scroll page for item visibility
				JavascriptExecutor js = (JavascriptExecutor) driver;
				int val = i * 100;
				val = 700 - val;
				js.executeScript("window.scrollBy(0," + val + ")");
				// Clicking on add to cart button for the item
				driver.findElement(By.xpath(plpItem)).click();
				// Added sleep wait to add item in cart and item load in cart
				wait(By.xpath(AddToCartButtononPDPXpath));
				// Click on add to cart button on PDP
				driver.findElement(By.xpath(AddToCartButtononPDPpath)).click();
				Thread.sleep(2000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}

			}
		}
	}

	public void add_FavToList_FromPDP(String AddtoFavPDPXpath, String CreateNewFavList, String FavListNameInputBox,
			String AddToFavButton) throws Throwable {
		wait(By.xpath(AddtoFavPDPXpath));
		driver.findElement(By.xpath(AddtoFavPDPXpath)).click();
		driver.findElement(By.xpath(CreateNewFavList)).click();

		wait(By.xpath(FavListNameInputBox));
		Thread.sleep(10000);
		driver.findElement(By.xpath(FavListNameInputBox)).sendKeys("Automation");

		wait(By.xpath(AddToFavButton));
		driver.findElement(By.xpath(AddToFavButton)).click();

		Thread.sleep(2000);
	}

	public void add_ItemToQuickOrder(String cartIconXPath, String quickOrderXXPath, String productTextCode,
			String productCode, String addToQuickOrderButton, String productCodeOnCart) throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(10000);
				wait(By.xpath(cartIconXPath));
				driver.findElement(By.xpath(cartIconXPath)).click();
				Thread.sleep(2000);
				wait(By.xpath(quickOrderXXPath));
				driver.findElement(By.xpath(quickOrderXXPath)).click();

				wait(By.xpath(productTextCode));
				driver.findElement(By.xpath(productTextCode)).sendKeys(productCode);

				wait(By.xpath(addToQuickOrderButton));
				driver.findElement(By.xpath(addToQuickOrderButton)).click();
				Thread.sleep(2000);
				wait(By.xpath(productCodeOnCart));
				Assert.assertTrue(driver.findElement(By.xpath(productCodeOnCart)).isDisplayed());
				Thread.sleep(3000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}
	}

	public void add_ToShippingInstructions(String OrderTotalOnCheckoutHeader, String OrderTotalOnCheckoutOrderSummary,
			String ShippingInstructions) throws Throwable {
		Thread.sleep(3000);
		wait(By.xpath(OrderTotalOnCheckoutHeader));
		Assert.assertTrue(driver.findElement(By.xpath(OrderTotalOnCheckoutHeader)).isDisplayed());
		wait(By.xpath(OrderTotalOnCheckoutOrderSummary));
		Assert.assertTrue(driver.findElement(By.xpath(OrderTotalOnCheckoutOrderSummary)).isDisplayed());
		wait(By.xpath(ShippingInstructions));
		driver.findElement(By.xpath(ShippingInstructions)).sendKeys("Automation Testing");
		Thread.sleep(3000);
	}

	public void add_ItemFromHistory_ToCart(String MyAccountonHeaderXpath, String OrderHistoryinMyAccountXpath,
			String OrderLinkinOrderHistoryXpath, String ReOrderButtononOrderHistory, String ItemNameInCart)
			throws Throwable {

		wait(By.xpath(MyAccountonHeaderXpath));
		driver.findElement(By.xpath(MyAccountonHeaderXpath)).click();
		wait(By.xpath(OrderHistoryinMyAccountXpath));
		driver.findElement(By.xpath(OrderHistoryinMyAccountXpath)).click();
		wait(By.xpath(OrderLinkinOrderHistoryXpath));
		driver.findElement(By.xpath(OrderLinkinOrderHistoryXpath)).click();
		wait(By.xpath(ReOrderButtononOrderHistory));
		driver.findElement(By.xpath(ReOrderButtononOrderHistory)).click();
		wait(By.xpath(ItemNameInCartXpath));
		Assert.assertTrue(driver.findElement(By.xpath(ItemNameInCartXpath)).isDisplayed());
		Thread.sleep(2000);

	}

	public void add_ItemToFav_FromQuickOrder(String CartIconXpath, String QuickOrderOnCartXpath,
			String ProductCodeTextBoxOnQuickOrderXpath, CharSequence ProductCode, String AddtoCartonQuickOrder,
			String AddToFavouritLinkOnCart, String RadioButtonOnFavList, String FavListNameInputBox,
			String AddToFavButton, String ContinueShoppingButton) throws Throwable {

		Thread.sleep(3000);
		wait(By.xpath(CartIconXpath));
		driver.findElement(By.xpath(CartIconXpath)).click();
		wait(By.xpath(QuickOrderOnCartXpath));
		driver.findElement(By.xpath(QuickOrderOnCartXpath)).click();
		wait(By.xpath(ProductCodeTextBoxOnQuickOrderXpath));
		driver.findElement(By.xpath(ProductCodeTextBoxOnQuickOrderXpath)).sendKeys(ProductCode);
		wait(By.xpath(AddtoCartonQuickOrder));
		driver.findElement(By.xpath(AddtoCartonQuickOrder)).click();
		Thread.sleep(3000);
		wait(By.xpath(AddToFavouritLinkOnCart));
		driver.findElement(By.xpath(AddToFavouritLinkOnCart)).click();
		wait(By.xpath(RadioButtonOnFavList));
		driver.findElement(By.xpath(RadioButtonOnFavList)).click();
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(3000);
				wait(By.xpath(FavListNameInputBox));
				driver.findElement(By.xpath(FavListNameInputBox)).sendKeys("Automation");
				wait(By.xpath(AddToFavButton));
				driver.findElement(By.xpath(AddToFavButton)).click();
				wait(By.xpath(ContinueShoppingButton));
				driver.findElement(By.xpath(ContinueShoppingButton)).click();
				Thread.sleep(3000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}

	}

	public void add_FavList(String FavListIconOnHeader, String FavListLinkText, String AddtoCurrentOrderButtonXpath)
			throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				wait(By.xpath(FavListIconOnHeader));
				driver.findElement(By.xpath(FavListIconOnHeader)).click();
				wait(By.linkText(FavListLinkText));
				driver.findElement(By.linkText(FavListLinkText)).click();
				wait(By.xpath(AddtoCurrentOrderButtonXpath));
				driver.findElement(By.xpath(AddtoCurrentOrderButtonXpath)).click();
				Thread.sleep(4000);
				break;
			} catch (InterruptedException e) {
				if (i > 2) {
					throw e;
				}
			}
		}
	}

	public void add_FavItem_ToCart(String FavListIconOnHeader, String AddTocartIconIDonFavlist, String ItemNameInCart)
			throws Throwable {

		Thread.sleep(3000);
		wait(By.xpath(FavListIconOnHeader));
		driver.findElement(By.xpath(FavListIconOnHeader)).click();
		Thread.sleep(3000);
		wait(By.xpath(AddTocartIconIDonFavlist));
		driver.findElement(By.xpath(AddTocartIconIDonFavlist)).click();
		Thread.sleep(3000);
		wait(By.xpath(ItemNameInCart));
		Assert.assertTrue(driver.findElement(By.xpath(ItemNameInCart)).isDisplayed());
		Thread.sleep(3000);
	}

	public void delete_FavList(String FavListIconOnHeader, String DeleteFavListId,
			String TextMessageOnFavlistdeletionXpath, String ClosePopup) throws Throwable {
		wait(By.xpath(FavListIconOnHeader));

		driver.findElement(By.xpath(FavListIconOnHeader)).click();
		wait(By.id(DeleteFavListId));
		driver.findElement(By.id(DeleteFavListId)).click();
		driver.switchTo().alert().accept();
		wait(By.xpath(TextMessageOnFavlistdeletionXpath));
		Assert.assertTrue(driver.findElement(By.xpath(TextMessageOnFavlistdeletionXpath)).isDisplayed());
		Thread.sleep(2000);
		wait(By.xpath(ClosePopup));
		// driver.findElement(By.xpath(ClosePopup)).click();
		Thread.sleep(2000);
	}

	public void add_ItemFromSearchPage(String AddtoCartButton, String CartIconXpath, String ItemNameInCartXpath)
			throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				driver.navigate().refresh();
				wait(By.xpath(SearchResultPageItem));
				// Mouseover on first item on search result page
				Thread.sleep(5000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				Mouseover(By.xpath(SearchResultPageItem));
				wait(By.xpath(AddtoCartButton));
				// Clicking on add to cart button for the item
				WebElement element2 = driver.findElement(By.xpath(AddtoCartButton));
				js.executeScript("arguments[0].click();", element2);
				// Added sleep wait to add item in cart and item load in cart
				// Wait for cart icon on header
				Thread.sleep(5000);
				WebElement element = driver.findElement(By.xpath(CartIconXpath));

				js.executeScript("arguments[0].click();", element);

				// Clicking on cart icon on header
				// driver.findElement(By.xpath(CartIconXpath)).click();
				wait(By.xpath(ItemNameInCartXpath));
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}
	}

	public void add_ToFavList_FromPLP(String OfficeSuppliesHeaderXpath, String AdhesivesSubcategoryLinkText,
			String PLPItem, String AddtoFavPLP, String CreateNewFavList, String FavListName, String AddtoFavButtonPLP)
			throws Throwable {

		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(5000);
				wait(By.xpath(OfficeSuppliesHeaderXpath));
				Mouseover(By.xpath(OfficeSuppliesHeaderXpath));
				wait(By.linkText(AdhesivesSubcategoryLinkText));
				driver.findElement(By.linkText(AdhesivesSubcategoryLinkText)).click();
				wait(By.xpath(PLPItem));
				JavascriptExecutor js = (JavascriptExecutor) driver;
				int val = i * 100;
				val = 700 - val;
				js.executeScript("window.scrollBy(0," + val + ")");
				Mouseover(By.xpath(PLPItem));
				wait(By.xpath(AddtoFavPLP));
				// Add to Favourites Popup
				driver.findElement(By.xpath(AddtoFavPLP)).click();
				driver.findElement(By.xpath(CreateNewFavList)).click();
				driver.findElement(By.xpath(FavListName)).sendKeys("OB_Test");
				wait(By.xpath(AddtoFavButtonPLP));
				driver.findElement(By.xpath(AddtoFavButtonPLP)).click();
				Thread.sleep(2000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}
	}

	public void add_FavSearch(String SearchInputBoxXpath, String SearchButtonClass, String SearchResultPageTitleXpath,
			String PLPItem, String AddtoFavSearch, String CreateNewFavList, String FavListNameSearch,
			String AddtoFavButtonSearch) throws Throwable {

		wait(By.xpath(SearchInputBoxXpath));

		Thread.sleep(10000);
		WebElement searchBox = driver.findElement(By.id("SimpleSearchForm_SearchTerm"));

		Actions actions = new Actions(driver);

		actions.moveToElement(searchBox).click().perform();
		JavascriptExecutor runJS = ((JavascriptExecutor) driver);
		runJS.executeScript("arguments[0].value='ink';", searchBox);
		driver.findElement(By.className(SearchButtonClass)).click();
		Thread.sleep(10000);
		wait(By.xpath(SearchResultPageTitleXpath));
		Thread.sleep(2000);
		wait(By.xpath(PLPItem));
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,550)");
		Mouseover(By.xpath(PLPItem));
		// Add to Favourites Popup
		wait(By.xpath(AddtoFavouritesPLPSearch));
		WebElement element = driver.findElement(By.xpath(AddtoFavouritesPLPSearch));
		js.executeScript("arguments[0].click();", element);

		Thread.sleep(2000);
		wait(By.xpath(RadioButtonOnFavList));
		driver.findElement(By.xpath(RadioButtonOnFavList)).click();
		Thread.sleep(2000);
		wait(By.xpath(FavListNameInputBox));
		driver.findElement(By.xpath(FavListNameInputBox)).sendKeys("Automation");
		wait(By.xpath(AddToFavButton));
		driver.findElement(By.xpath(AddToFavButton)).click();
		Thread.sleep(2000);
		wait(By.xpath(ContinueShoppingButton));
		driver.findElement(By.xpath(ContinueShoppingButton)).click();
		Thread.sleep(3000);

	}

	public void continueShopping(String ContinueShopButton) throws Throwable {
		wait(By.xpath(ContinueShopButton));
		driver.findElement(By.xpath(ContinueShopButton)).click();

		Thread.sleep(2000);
	}

	public void remove_ItemFromCart(String removeCartIcon) throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(5000);
				// Wait for remove item link displaying with item
				wait(By.xpath(removeCartIcon));
				// Clicking on remove item
				driver.findElement(By.xpath(removeCartIcon)).click();
				// Click on on confirmation alert message
				driver.switchTo().alert().accept();

				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				}
			}
		}

	}

	public void remove_OrderedCart(String RemoveOrderCartXpath) throws Throwable {

		wait(By.xpath(RemoveOrderCartXpath));
		// Clicking on remove item
		driver.findElement(By.xpath(RemoveOrderCartXpath)).click();
		// Click on on confirmation alert message
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	public void remove_FavItem_FromCart(String RemoveOrderCartXpath) throws Throwable {
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(2000);
				wait(By.xpath(RemoveOrderCartXpath));
				// Clicking on remove item
				driver.findElement(By.xpath(RemoveOrderCartXpath)).click();
				// Click on on confirmation alert message
				driver.switchTo().alert().accept();
				Thread.sleep(2000);
				break;
			} catch (Exception e) {
				if (i > 2) {
					throw e;
				} else
					e.printStackTrace();
			}
		}
	}

	public void remove_ItemCart(String RemoveItemCartXpath) throws Throwable {

		wait(By.xpath(RemoveItemCartXpath));
		error = "Remove item";
		// Clicking on remove item
		driver.findElement(By.xpath(RemoveItemCartXpath)).click();
		Thread.sleep(5000);
	}

	public void delete_FavListFromCart(String FavListIconOnHeader, String DeleteFavListId,
			String TextMessageOnFavlistdeletionXpath, String ClosePopup) throws Throwable {
		driver.navigate().refresh();
		wait(By.xpath(FavListIconOnHeader));
		driver.findElement(By.xpath(FavListIconOnHeader)).click();
		wait(By.id(DeleteFavListId));
		driver.findElement(By.id(DeleteFavListId)).click();
		driver.switchTo().alert().accept();
		wait(By.xpath(TextMessageOnFavlistdeletionXpath));
		Assert.assertTrue(driver.findElement(By.xpath(TextMessageOnFavlistdeletionXpath)).isDisplayed());
		Thread.sleep(2000);
		wait(By.xpath(ClosePopup));
		driver.findElement(By.xpath(ClosePopup)).click();
		Thread.sleep(2000);
	}

	public void delete_FavList() throws Throwable {
		driver.navigate().refresh();
		wait(By.xpath(FavlistDelete));
		driver.findElement(By.xpath(FavlistDelete)).click();
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		// driver.navigate().refresh();
		wait(By.xpath(ClosePopup));
		driver.findElement(By.xpath(ClosePopup)).click();

	}

	public void execute_search(String SearchInputBoxXpath, CharSequence ProdcutNametosearch, String SearchButtonClass,
			String SearchResultPageTitleXpath) throws Throwable {
		wait(By.xpath(SearchInputBoxXpath));
		// Enter keyword in search input box
		Thread.sleep(10000);
		WebElement searchBox = driver.findElement(By.id("SimpleSearchForm_SearchTerm"));

		Actions actions = new Actions(driver);

		actions.moveToElement(searchBox).click().perform();
		JavascriptExecutor runJS = ((JavascriptExecutor) driver);
		runJS.executeScript("arguments[0].value='ink';", searchBox);

		// Click on search button to search entered keyword

		driver.findElement(By.className(SearchButtonClass)).click();
		Thread.sleep(2000);

		// Wait for search result page
		wait(By.xpath(SearchResultPageTitleXpath));

	}

	public void loginIfEnabled() throws Throwable {
		System.out.println("The value of login is " + enableLogin);
		if (null != enableLogin && enableLogin.equalsIgnoreCase("true")) {

			return;
		}
		login();

	}

	public void login() throws Throwable {

		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(10000);
				wait(By.xpath(LoginIconXpath));
				driver.findElement(By.xpath(LoginIconXpath)).click();
				wait(By.xpath(LogonIDInputXpath));
				driver.findElement(By.xpath(LogonIDInputXpath)).sendKeys(Username);
				wait(By.xpath(LoginPasswordInputXpath));
				driver.findElement(By.xpath(LoginPasswordInputXpath)).sendKeys(Password);
				wait(By.xpath(SignInButtonXpath));
				driver.findElement(By.xpath(SignInButtonXpath)).click();
				Thread.sleep(10000);
				System.out.println("New Login Passed " + i);
				break;
			} catch (Exception e) {
				driver.navigate().refresh();
				if (i > 2) {
					throw e;
				}

			}
		}
	}

	public void signout() throws Throwable {

		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(10000);
				wait(By.xpath(SignOutQuickLinkIconXpath));
				driver.findElement(By.xpath(SignOutQuickLinkIconXpath)).click();
				wait(By.xpath(SignOutButtonXpath));
				driver.findElement(By.xpath(SignOutButtonXpath)).click();
				System.out.println("Signout Passed " + i);
				break;
			} catch (Exception e) {
				driver.navigate().refresh();
				if (i > 2) {
					throw e;
				}

			}
		}
	}

	public void checkout_selectPaymentMethod(String PaymentMethod) throws Throwable {
		try {
			wait(By.xpath(PaymentMethod));
			driver.findElement(By.xpath(PaymentMethod)).click();
		} catch (Throwable e) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath(PaymentMethod)));
		}
	}

	public void checkout_addCCDetails() throws Throwable {
		Select payMethodId_1 = new Select(driver.findElement(By.id("payMethodId_1")));
		payMethodId_1.selectByIndex(1);
		wait(By.xpath(CardHolderNameVisaCreditCard));
		driver.findElement(By.xpath(CardHolderNameVisaCreditCard)).sendKeys(LiveCreditCardHolderName);
		wait(By.xpath(CardNumberVisaCreditCard));
		driver.findElement(By.xpath(CardNumberVisaCreditCard)).sendKeys(LiveCreditCardNumber);
		wait(By.xpath(CvvVisaCreditCard));
		driver.findElement(By.xpath(CvvVisaCreditCard)).sendKeys(LiveCreditCardCvv2Number);
		Select expire_month_1 = new Select(driver.findElement(By.id("expire_month_1")));
		expire_month_1.selectByValue("11");
		Select expire_year_1 = new Select(driver.findElement(By.id("expire_year_1")));
		expire_year_1.selectByValue("2024");
		Thread.sleep(10000);
	}

	public void perform_checkout() throws Throwable {
		wait(By.xpath(CompleteOrderButtonOnCheckout));
		driver.findElement(By.xpath(CompleteOrderButtonOnCheckout)).click();
		Thread.sleep(5000);
	}

	public void add_FavToList_FromPLP(String plpItem, String AddtoFavouritesPLPSearch, String RadioButtonOnFavList,
			String FavListNameInputBox, String AddToFavButton, String ContinueShoppingButton) throws Throwable {

		wait(By.xpath(plpItem));

		// Adding scroll to scroll page for item visibility
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,550)");
		// Mousehover on item to view add to cart button
		Mouseover(By.xpath(plpItem));
		// Waiting for add to fav button visibility after mousehover
		wait(By.xpath(AddtoFavouritesPLPSearch));
		driver.findElement(By.xpath(AddtoFavouritesPLPSearch)).click();
		Thread.sleep(2000);
		wait(By.xpath(RadioButtonOnFavList));
		driver.findElement(By.xpath(RadioButtonOnFavList)).click();
		Thread.sleep(2000);
		wait(By.xpath(FavListNameInputBox));
		driver.findElement(By.xpath(FavListNameInputBox)).sendKeys("Automation");
		wait(By.xpath(AddToFavButton));
		driver.findElement(By.xpath(AddToFavButton)).click();
		Thread.sleep(2000);
		wait(By.xpath(ContinueShoppingButton));
		driver.findElement(By.xpath(ContinueShoppingButton)).click();
		Thread.sleep(3000);

	}

}
