package com.solveda.ob.testscript;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.solveda.ob.reporting.AutomationUtility;
import com.solveda.ob.reporting.XPathConstants;

public class Validate extends AutomationUtility implements XPathConstants{

	@Test(priority = 1, description="Validate >> Verify item in cart is 0 and favourite list should not be created.")
	public void ValidateCartAndFavList() throws Throwable
	{
		{
			test=extent.createTest("Verify item in cart is 0 and favourite list should not be created.");
			String error = null;
			try {

				System.out.println("Validate ValidateCartAndFavList Login");

				login();

				validateCartToEmpty();

				Thread.sleep(5000);

				driver.navigate().refresh();

				wait(By.id(HomeMenuHeaderId));

				driver.findElement(By.id(HomeMenuHeaderId)).click();	

				validateFavList();	

				Thread.sleep(5000);

				driver.navigate().refresh();

				wait(By.id(HomeMenuHeaderId));

				driver.findElement(By.id(HomeMenuHeaderId)).click();


			}
			catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("Validate ValidateCartAndFavList Signout");

				signout();
			}
		}

	}

}
