package com.solveda.ob.testscript;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.solveda.ob.reporting.*;


public class PDP extends AutomationUtility implements XPathConstants
{		
	@Test(priority = 1, description="PDP >> Verify item is adding to cart from PDP")
	public void AddtoCartFromPLP() throws Throwable
	{
		{
			test=extent.createTest("Verify item is adding to cart from PDP");
			String error = null;
			try {
				// Fetching locator's addresses from property file
				System.out.println("PDP AddtoCartFromPLP Login");
				login();

				navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

				add_PDPItemToCart(PLPItem, AddToCartButtononPDPXpath);

				show_miniCart(CartIconOnHeader, ItemNameInCartXpath);

				remove_ItemFromCart(RemoveOrderCartXpath);
				Thread.sleep(5000);
				driver.navigate().refresh();

				validate_CartCount(CartCountonHeaderXpath, "0");

				wait(By.id(HomeMenuHeaderId));

				driver.findElement(By.id(HomeMenuHeaderId)).click();	  


			} catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("PDP AddtoCartFromPLP Signout");
				signout();
			}
		}

	}
	@Test(priority = 2, description="PDP >> Verify product is adding to Favourites via PDP")
	public void AddtoFavouritePDP() throws Throwable
	{
		{
			test=extent.createTest("Verify product is adding to Favourites via PDP");
			String error = null;
			try
			{
				System.out.println("PDP AddtoFavouritePDP Login");
				login();

				navigate_ToCategoryPage(L1CategoryXPath, L2CategoryLinkPath, L3CategoryTextXPath);

				navigate_ToPDPPage_fromPLP(PLPItem);

				add_FavToList_FromPDP(AddtoFavPDPXpath, CreateNewFavList, FavListNameInputBox, AddToFavButton);

				//Continue Shopping Popup
				continueShopping(ContinueShopButton);		    

				//Favourites screen
				navigate_ToFavList(FavIconOnHeader, FavNameInFav, FavlistDelete, FavlistDeleteClose);

			} 	    
			catch(AssertionError e)
			{
				test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
			}
			finally {
				System.out.println("PDP AddtoFavouritePDP Signout");
				signout();
			}
		}
	}

}
