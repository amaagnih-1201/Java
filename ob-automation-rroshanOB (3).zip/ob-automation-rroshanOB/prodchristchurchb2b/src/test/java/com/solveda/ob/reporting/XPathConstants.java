package com.solveda.ob.reporting;
import com.solveda.ob.testscript.PropReader;

public interface XPathConstants {

	public String  Username = PropReader.getProp("Username");
	public String  Password = PropReader.getProp("Password");
	public String  enableCCOnPayment = PropReader.getProp("enableCCOnPayment");
	public String  enableLogin=PropReader.getProp("enableLogin");
	
    public String AddtoFavButtonSearch = PropReader.getProp("AddtoFavButtonSearch");			
    public String FavListNameSearch = PropReader.getProp("FavListNameSearch");
    public String OfficeSuppliesHeaderXpath = PropReader.getProp("OfficeSuppliesHeaderXpath");
    public String AdhesivesSubcategoryLinkText = PropReader.getProp("AdhesivesSubcategoryLinkText");
    public String AddtoFavPLP = PropReader.getProp("AddtoFavPLP");
    public String AddtoFavButtonPLP = PropReader.getProp("AddtoFavButtonPLP");			
    public String FavListName = PropReader.getProp("FavListName");
    public String FavNameInFavListXpath = PropReader.getProp("FavNameInFavListXpath");
            
    // Fetching locator's addresses from property file
    public String PaperSuppliesHeaderXpath = PropReader.getProp("PaperSuppliesHeaderXpath");
    // Fetch locators value from property file
    public String SearchResultPageTitleXpath = PropReader.getProp("SearchResultPageTitleXpath");
    public String ItemNameInCartXpath = PropReader.getProp("ItemNameInCartXpath");
  // Fetch locators value from property file
	public String SearchInputBoxXpath = PropReader.getProp("SearchInputBoxXpath");
	public String SearchButtonClass = PropReader.getProp("SearchButtonClass");
	public String SearchResultPageItem = PropReader.getProp("SearchResultPageItem");
	public String FirstItemNameOnSearchResultPage = PropReader.getProp("FirstItemNameOnSearchResultPage");
	public String ItemNameOnPDPAfterSearchResultXpath = PropReader.getProp("ItemNameOnPDPAfterSearchResultXpath");
	public String ProdcutNametosearch = PropReader.getProp("ProdcutNametosearch");
	
    public String  HomeMenuHeaderId = PropReader.getProp("HomeMenuHeaderId");
    public String AddtoFavPDPXpath = PropReader.getProp("AddtoFavPDPXpath");
    public String CreateNewFavList = PropReader.getProp("CreateNewFavList");
    public String ContinueShopButton = PropReader.getProp("ContinueShopButton");
    public String FavIconOnHeader = PropReader.getProp("FavIconOnHeader"); 
    public String FavNameInFav = PropReader.getProp("FavNameInFav");
    public String FavlistDelete = PropReader.getProp("FavlistDelete");
    public String FavlistDeleteClose = PropReader.getProp("FavlistDeleteClose");

    public String CopyPaperSubcategoryLinkText = PropReader.getProp("CopyPaperSubcategoryLinkText");
    public String WhiteCopyPaperCategoryTextPLPXpath = PropReader.getProp("WhiteCopyPaperCategoryTextPLPXpath");
    public String gotoPDP = PropReader.getProp("GoToPDP");
   	// Fetching locator's addresses from property file
	public String  L1CategoryXPath = PropReader.getProp("L1CategoryXPath");
    public String  L2CategoryLinkPath = PropReader.getProp("L2CategoryLinkPath");
    public String  L3CategoryTextXPath = PropReader.getProp("L3CategoryTextXPath");

    public String  LoginIconXpath = PropReader.getProp("LoginIconXpath");
	public String  MyAccountIconIconXpath = PropReader.getProp("MyAccountIconIconXpath");
	
    public String  PLPItem = PropReader.getProp("PLPItem");
	public String  AddtoCartButton = PropReader.getProp("AddtoCartButton");
    public String  CartIconOnHeader = PropReader.getProp("CartIconOnHeader"); 
	public String  CartCountonHeaderXpath = PropReader.getProp("CartCountonHeaderXpath");
	public String  RemoveItemCartXpath=PropReader.getProp("RemoveItemCartXpath");
	public String  RemoveOrderCartXpath=PropReader.getProp("RemoveOrderCartXpath");
	public String  QuickOrderOnCartXpath = PropReader.getProp("QuickOrderOnCartXpath");
	public String  ProductCodeTextBoxOnQuickOrderXpath = PropReader.getProp("ProductCodeTextBoxOnQuickOrderXpath");
	public String  ProductCode = PropReader.getProp("ProductCode");
	public String  AddtoCartonQuickOrder = PropReader.getProp("AddtoCartonQuickOrder");
	public String  ProductCodeOnCart = PropReader.getProp("ProductCodeOnCart");
	public String  CartIconXpath = PropReader.getProp("CartIconXpath");
	public String  LogonIDInputXpath = PropReader.getProp("LogonIDInputXpath");
	public String  LoginPasswordInputXpath = PropReader.getProp("LoginPasswordInputXpath");
	public String  SignInButtonXpath = PropReader.getProp("SignInButtonXpath");
	public String  SignOutQuickLinkIconXpath = PropReader.getProp("SignOutQuickLinkIconXpath");
	public String  SignOutButtonXpath = PropReader.getProp("SignOutButtonXpath");
	public String  CheckOutButton = PropReader.getProp("CheckOutButton");
	public String  ShippingInstructions = PropReader.getProp("ShippingInstructions");
	public String  OrderTotalOnCheckoutHeader = PropReader.getProp("OrderTotalOnCheckoutHeader");
	public String  OrderTotalOnCheckoutOrderSummary = PropReader.getProp("OrderTotalOnCheckoutOrderSummary");
	public String  CompleteOrderButtonOnCheckout = PropReader.getProp("CompleteOrderButtonOnCheckout");
	public String  OrderConfirmationHeader = PropReader.getProp("OrderConfirmationHeader");
	public String  OrderConfirmationMessage = PropReader.getProp("OrderConfirmationMessage");
	public String  PaymentMethod = PropReader.getProp("PaymentMethod");
	public String  CardHolderNameVisaCreditCard = PropReader.getProp("CardHolderNameVisaCreditCard");
	public String  CardNumberVisaCreditCard = PropReader.getProp("CardNumberVisaCreditCard");
	public String  CvvVisaCreditCard = PropReader.getProp("CvvVisaCreditCard");
	public String  LiveCreditCardHolderName = PropReader.getProp("LiveCreditCardHolderName");
	public String  LiveCreditCardNumber = PropReader.getProp("LiveCreditCardNumber");
	public String  LiveCreditCardCvv2Number = PropReader.getProp("LiveCreditCardCvv2Number");
	public String  MyAccountonHeaderXpath = PropReader.getProp("MyAccountonHeaderXpath");
	public String  OrderHistoryinMyAccountXpath = PropReader.getProp("OrderHistoryinMyAccountXpath");
	public String  OrderLinkinOrderHistoryXpath = PropReader.getProp("OrderLinkinOrderHistoryXpath");
	public String  ReOrderButtononOrderHistory = PropReader.getProp("ReOrderButtononOrderHistory");
	public String  AddToFavouritLinkOnCart = PropReader.getProp("AddToFavouritLinkOnCart");
	public String  FavListNameInputBox = PropReader.getProp("FavListNameInputBox");
	public String  RadioButtonOnFavList = PropReader.getProp("RadioButtonOnFavList");
	public String  AddToFavButton = PropReader.getProp("AddToFavButton");
	public String  ContinueShoppingButton = PropReader.getProp("ContinueShoppingButton");
	public String  FavListIconOnHeader = PropReader.getProp("FavListIconOnHeader");
	public String  AddTocartIconIDonFavlist = PropReader.getProp("AddTocartIconIDonFavlist");
	public String  FavListLinkText = PropReader.getProp("FavListLinkText");
	public String  AddtoCurrentOrderButtonXpath = PropReader.getProp("AddtoCurrentOrderButtonXpath");
	public String  DeleteFavListId = PropReader.getProp("DeleteFavListId");
	public String  TextMessageOnFavlistdeletionXpath = PropReader.getProp("TextMessageOnFavlistdeletionXpath");
	public String  ClosePopup = PropReader.getProp("ClosePopup");
    public String AddtoFavouritesPLPSearch = PropReader.getProp("AddtoFavouritesPLPSearch");
    public String AddToCartButtononPDPXpath = PropReader.getProp("AddToCartButtononPDPXpath");
    public String MinimumAmount = PropReader.getProp("MinimumAmount");
    public String ReOrderButton = PropReader.getProp("ReOrderButton");
}
