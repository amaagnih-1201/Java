package com.solveda.ob.testscript;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.solveda.ob.reporting.AutomationUtility;

public class WebSiteLoad extends AutomationUtility {
	
	@Test(priority = 1, description="Verify page is refreshing after clicking on page website logo",invocationCount=10)
	public void PageRefreshSiteLogo() throws Throwable
	{
		test=extent.createTest("Verify page is refreshing after clicking on page website logo");
		String error = null;
		try {
		String SiteLogoXpath = PropReader.getProp("SiteLogoXpath");
		error = SiteLogoXpath;
		// wait fir website logo
		wait(By.xpath(SiteLogoXpath));
		error = SiteLogoXpath;
		// Click on website logo
		driver.findElement(By.xpath(SiteLogoXpath)).click();
		// Wait for 30 seconds
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Verify website logo is displayed and working
		validateMultipleIDs("HomePage_ID", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_1", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_2", "Home Page");
		validateMultipleIDs("HomePage_Secondlayer_ID", "Home Page");
		validateMultipleIDs("HomePage_Banner", "Home Page");
		validateMultipleIDs("InsightBusiness", "Home Page");
		validateMultipleIDs("HomePage_Footer_ID", "Home Page");
		validateMultipleLinksXPath("HomePage_Footer_Link", "Home Page");
		
		}	
		catch(AssertionError e)
	    {
		//test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
	}
	}

	@Test(priority = 2, description="Verify page is refreshing after clicking on home icon", invocationCount=10)
	public void PageRefreshHomeIcon() throws Throwable
	{
		test=extent.createTest("Verify page is refreshing after clicking on home icon");
		String error = null;
		try {
		String HomeMenuHeaderId = PropReader.getProp("HomeMenuHeaderId");
		error = HomeMenuHeaderId;
		// wait for home menu header
		wait(By.id(HomeMenuHeaderId));
		error = HomeMenuHeaderId;
		// click on home menu header
		driver.findElement(By.id(HomeMenuHeaderId)).click();
		// wait for 30 sec
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// Verify that home menu link is working
		validateMultipleIDs("HomePage_ID", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_1", "Home Page");
		validateMultipleLinksXPath("HomePageNav_XPathLinks_2", "Home Page");
		validateMultipleIDs("HomePage_Secondlayer_ID", "Home Page");
		validateMultipleIDs("HomePage_Banner", "Home Page");
		validateMultipleIDs("InsightBusiness", "Home Page");
		validateMultipleIDs("HomePage_Footer_ID", "Home Page");
		validateMultipleLinksXPath("HomePage_Footer_Link", "Home Page");
		
		}	
		catch(AssertionError e)
	    {
		//test.log(Status.FAIL, MarkupHelper.createLabel(error + "  is not displayed", ExtentColor.RED));
	}
	}
	
	
	
}
